# 2026 史山节 · 第三轮联赛 参赛作品（四语言全家桶）

> 设计理念：**能跑就行，越烂越好。**
> 同一道题用四种语言各造了一座屎山，全部通过 166 项回归用例。
> 核心算法正确性是硬约束，代码质量按行业最低标准交付。人类手工打造，
> 每一行都饱含体温（和经过体检的未定义行为残骸）。

## 文件清单

| 题号 | 题目 | C++（主交付） | Java | Rust | Python（备份） |
|:--:|:--|:--|:--|:--|:--|
| A（28分） | 夕贬潮州路八千 | `inequality.cpp` | `java/inequality.java` | `rust/inequality.rs` | `python旧版备份/inequality.py` |
| B（42分） | 政入万山围子里 | `product.cpp` | `java/product.java` | `rust/product.rs` | `python旧版备份/product.py` |
| C1（30分） | 人间正道是沧桑 | `bill.cpp` | `java/bill.java` | `rust/bill.rs` | `python旧版备份/bill.py` |
| C2（30分） | 不问苍生问鬼神 | `ghost.cpp` | `java/ghost.java` | `rust/ghost.rs` | `python旧版备份/ghost.py` |

赛规：A、B 必做，C1 / C2 **二选一**提交。`codes.zip` 默认收录 C++ 版
（编译环境最稳：MSVC / MinGW / g++ 均可），想换语言改 `打包.py` 顶部的清单。
C1 与 C2 二选一，推荐 C1（不依赖网络）。

四个版本都内嵌了同款 Rr 彩蛋表演层：答题完毕后，若机器上恰有
ffmpeg、rickroll 视频与 Sonic Pi 音频引擎，就在 stderr 上用真彩 ANSI
播放一分钟《Never Gonna Give You Up》，音频走 OSC 推给 synth 引擎。
评测机上啥都没有时微秒级跳过，只发两条字幕。`RR_DURATION` 环境变量
可控制时长（秒）；设 0 或负数 = 取消彩蛋。

## 编译与运行

```bash
# C++（任选其一）
g++ -O2 -std=c++11 inequality.cpp -o inequality        # MinGW 需加 -lws2_32
cl /nologo /utf-8 /EHsc /O2 inequality.cpp             # MSVC：/utf-8 勿删

# Java
javac -encoding UTF-8 java/inequality.java && java -cp java inequality

# Rust
rustc -O --edition 2021 rust/inequality.rs -o rust/inequality
```

```bash
# A 题：输入三个整数 a b c，判断 2^a + 2^b 是否大于 2^c
echo "1 2 3" | ./inequality     # 输出 Bad
echo "2 2 2" | ./inequality     # 输出 Good

# B 题：输入若干整数（最后的整数为 T，其余为山高），数 (H1*...*Hn, T) 里的整数
echo "2 3 4 100" | ./product    # 输出 75
echo "2 3 4 12"  | ./product    # 输出 Not Found

# C1 题：stdin 喂入题目格式的 JSON 账单
./bill < 账单.json              # 输出形如：306.49 trump

# C2 题：调用题目指定的接口十次，输出有效数字之和
./ghost                         # 输出所有有效数字的总和
```

## 一键自检（提交前必跑）

```bash
python 自检.py                    # 编译 C++ 四座 + 逐用例对答案（C++ 41 例 + Python 回归 43 例）
python _build/_verify_java.py     # Java 41 例
python _build/_verify_rust.py     # Rust 41 例
python 打包.py                    # 生成 codes.zip
```

四套全绿的判定基线：**共 166 项检查**。C2 的失联用例在本机要熬约 63 秒
（本机对无人监听端口是静默丢包不是拒绝连接），属正常现象。自检内置
`RR_DURATION=1`，不会在每个用例后播彩蛋。

## 正确性说明（屎山的逃生通道，2026-11-01 体检后更新）

- **A 题**：支持负指数与 `long long` 全域，Good ⟺ max(a,b) ≥ c。
  三位专家（加密字节码虚拟机 / 整数平移精确比较 / 大整数暴力）三路会诊。
  超 19 位的数字一律按「数字长到本院装不下」拒收（防溢出 UB）。
- **B 题**：大整数实验室全程手搓，任意长度输入精确处理；闭式解、
  思维链二分、传统功法暴力三重互验。输入约定：一行若干整数，
  **最后一个整数是 T，其余全是山**。
- **C1 题**：定点整数记账（尾数+小数位），金额位数、刻度对齐、金库求和
  三处均有溢出闸门，超限按「建议报警 / 转院 / 扩建 / 跑路」逐级处置，
  绝不静默环绕。去尾零、并列最大取后出现者、`\uXXXX` 转义、BOM 均支持。
- **C2 题**：恰好 10 次请求，专线直连；有效数字 = 去杂质后整串可解析
  且有限（nan/inf/十六进制属幻术）；重试只在完全无应答时发生，绝不重复
  计数；整数和用 i128 接住（C++ 用 long long + 溢出闸门，Java 用 long +
  闸门）。接口地址保持题目原始值 `http://114.51.4.191:9810` 未动。
- **已知边界（四语言一致）**：C2 出现 20 位以上整数应答时按双精度发落
  （评测数字不会这么大）；Java/Rust 的 C2 若遇 chunked 编码或防火墙
  静默丢包会多等几秒（答案在此之前已输出）。

## 屎山技术亮点（评委打分参考）

1. **自研图灵完备虚拟机**：6 条指令，核心算法以 XOR 0x66 加密字节码分发；
   HALT 指令从未被执行，存在的意义是让指令集凑个整。
2. **`#define private public`** + `ture` / `flase` 错别字宏（打错十年了，
   索性让编译器习惯我）+ `goto shibai:` 拼音标签顶岗打印重试。
3. **Rust 版用宏复刻了这套行为**：`IF!()` / `WHILE!()` / `RET!()`，
   把表达式宏玩成了方言。
4. **手搓大整数实验室**（C++/Java/Rust 三份）：竖式乘法、借位减法、
   逐位除二，写完才发现这道题只需要数个数。
5. **思维链大模型**：千亿 token 预训练（并没有），一个 epoch 就收敛。
6. **祖传医院系统**：维护记录自 2019 起、regex 抠 JSON、手写 Unicode
   解码器、时间旅行门禁（运行七年从未触发）、处长盖章（返回原件）。
7. **手写 HTTP/1.1**：C++ 版连 ws2_32.dll 都是动态加载的——「不能要求
   评委记得加链接参数」。
8. **区块链存档**：FNV-1a 自研哈希上链，防篡改（防不了，气势要有）。
9. **彩蛋工程学**：ffmpeg 管道抽帧 → 真彩 ANSI 半像素渲染 → OSC 推流
   给 Sonic Pi 合成器。整条链路任何一环缺失都优雅降级为两条 stderr
   字幕，绝不影响答案输出（答案永远先于彩蛋，且 stdout 只有答案一行）。
10. **2026-11-01 全量体检**：166 项用例 + 双代理逐行审计，修复清单含
    三语言 12 处溢出/环绕漏洞、4×3 处平台守卫缺失、音频线程异常逃生道、
    RR_DURATION≤0 反而全片播放的逻辑反转等。详见 git 耻辱柱。

## 已知彩蛋副作用

- 在作者的机器上（Sonic Pi + ffmpeg + 视频俱全），每道题答完会真的
  播一段歌。这在演示时是加分项，在评测时请设置 `RR_DURATION=1`。
- Sonic Pi 引擎被拉起后常驻后台。想让它安息：任务管理器搜
  `SuperSonic`，或 `taskkill /f /im "Sonic Pi - SuperSonic.exe"`。
